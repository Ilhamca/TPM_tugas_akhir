import 'package:flutter/material.dart';
import 'package:tugas_akhir/screen/inventory_page.dart';
import 'package:tugas_akhir/screen/conversion_page.dart';
import 'package:tugas_akhir/screen/profile_page.dart'; // Import halaman profil baru
import 'package:tugas_akhir/screen/shipping_page.dart';

class MenuPage extends StatefulWidget {
  const MenuPage({super.key, required this.username});

  final String username;

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  int _selectedIndex = 0;

  // Daftar halaman yang akan ditampilkan berdasarkan index yang dipilih
  late final List<Widget> _pages = [
    InventoryPage(username: widget.username),
    const ConversionPage(),
    const ShippingPage(),
    const ProfilePage(), // <-- Memanggil file ProfilePage yang baru dibuat
  ];

  // Fungsi untuk menangani navigasi bawah
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],

      // Implementasi Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed, 
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.orange.shade700,
        unselectedItemColor: Colors.grey.shade600,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.inventory_2),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.public), 
            label: 'International'
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_shipping),
            label: 'Pengiriman',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person), 
            label: 'Profil' // Menuju halaman Profil & Pengaturan
          ),
        ],
      ),
    );
  }

  // ==========================================
  // WIDGET HALAMAN 3: SARAN DAN KESAN TPM
  // (Saran TPM tetap dipertahankan di sini untuk menghemat file, atau bisa dipisah nanti)
  // ==========================================
  Widget _buildSaranTPMPage() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Saran & Kesan Mata Kuliah',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Teknologi dan Pemrograman Mobile (TPM)',
              style: TextStyle(fontSize: 16, color: Colors.blueGrey),
            ),
            const SizedBox(height: 24),
            TextField(
              maxLines: 5,
              decoration: InputDecoration(
                hintText:
                    'Tuliskan kesan dan saran Anda selama mengikuti mata kuliah ini...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Saran berhasil dikirim! Terima kasih.'),
                    ),
                  );
                },
                child: const Text('Kirim Saran'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}